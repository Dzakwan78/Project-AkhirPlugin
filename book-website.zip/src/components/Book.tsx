import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { InterBook } from './InterBook'; 

function Book() {
    const [bookList, setBookList] = useState<InterBook[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchBooks = async () => {
            try {
                const response = await axios.get("https://author-book-genre.vercel.app/api/book");
                setBookList(response.data.data);
            } catch (err) {
                console.error(err); 
                setError("Gagal mengambil data");
            } finally {
                setLoading(false);
            }
        };
        fetchBooks();
    }, []);

    if (loading) return <p>Tunggu sebentar MasBro...</p>;
    if (error) return <p>{error}</p>;

    return (
        <div>
            <h1>Book List</h1>
            <ul style={{ listStyleType: 'none', padding: 0 }}>
                {bookList.map((book) => (
                    <li key={book.id} style={{ marginBottom: '20px', border: '1px solid #ccc', padding: '10px', borderRadius: '5px' }}>
                        <a href={book.url} target="_blank" rel="noopener noreferrer">
                            <img src={book.coverImage} alt={book.title} style={{ width: '150px', height: 'auto', marginRight: '10px' }} />
                        </a>
                        <div style={{ display: 'inline-block', verticalAlign: 'top' }}>
                            <h2 style={{ margin: '0' }}>{book.title}</h2>
                            <p><strong>Author:</strong> {book.author}</p>
                            <p><strong>Publication Date:</strong> {book.publicationDate}</p>
                            <p><strong>Description:</strong> {book.description}</p>
                            <a href={book.detailsUrl} target="_blank" rel="noopener noreferrer" style={{ color: 'blue', textDecoration: 'underline' }}>
                                View Details
                            </a>
                        </div>
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default Book;